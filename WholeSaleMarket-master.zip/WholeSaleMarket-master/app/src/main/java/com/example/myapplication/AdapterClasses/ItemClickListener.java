package com.example.myapplication.AdapterClasses;

public interface ItemClickListener {
    void onClick(String s, int position);
}