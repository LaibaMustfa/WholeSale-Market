package com.example.myapplication.AdapterClasses;

public interface ItemClickListenerCart {
    void onClick(String s);
}