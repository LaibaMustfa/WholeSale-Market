package com.example.myapplication.Settings;

public interface NameInterface {
    public void onclick(String Name);
}
